from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec

def logout_webpage(driver):
    driver.find_element(By.XPATH, "//p[@class='oxd-userdropdown-name']").click()
    logout_button = WebDriverWait(driver, 10).until(ec.presence_of_element_located((By.XPATH,
                                                                                   "//a[text()='Logout']")))
    logout_button.click()
