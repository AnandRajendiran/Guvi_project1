import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec


def emloyee_list_button(driver):
    employee_list_element = WebDriverWait(driver, 20).\
        until(ec.presence_of_element_located((By.XPATH, "//li[@class='oxd-topbar-body-nav-tab --visited']")))
    employee_list_element.click()
    time.sleep(10)
