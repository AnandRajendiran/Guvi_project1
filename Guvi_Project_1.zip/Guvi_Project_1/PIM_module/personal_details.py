import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By


class personal_details:

    def __init__(self, driver):
        self.personal_details = driver

    Other_Id_locator = "(//input[@class='oxd-input oxd-input--active'])[4]"
    # ---------------------------------------------------------------------------

    Driving_lic_locator = "(//div[@class='oxd-input-group oxd-input-field-bottom-space'])[" \
                          "7]/div//following-sibling::div/input[@class='oxd-input oxd-input--active']"
    # --------------------------------------------------------------------------------

    Driving_loc_Date_locator = "(//div[@class='oxd-input-group oxd-input-field-bottom-space'])[" \
                               "8]/div//following-sibling::div/div/div/input[@class='oxd-input oxd-input--active']"
    # ----------------------------------------------------------------------------

    SSIN_number_locator = "(//div[@class='oxd-input-group oxd-input-field-bottom-space'])[" \
                          "9]/div/following-sibling::div/input[@class='oxd-input oxd-input--active']"
    # -----------------------------------------------------------------
    SIN_number_locator = "(//div[@class='oxd-input-group oxd-input-field-bottom-space'])" \
                         "[10]/div/following-sibling::div/input[@class='oxd-input oxd-input--active']"
    # -----------------------------------------------------------------
    Nationality_locator = "(//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow'])[1]"
    # -----------------------------------------------------------------
    Nationality_indian_locator = "//span[contains(text(),'India')]"
    # --------------------------------------------------------------
    Martial_status_locator = "(//div[@class='oxd-select-text--after'])[2]"
    # ----------------------------------------------------------------
    Martial_status_single_locator = "//span[text() = 'Single']"
    # -----------------------------------------------------------------
    Date_of_birth_locator = "(//div[@class='oxd-input-group oxd-input-field-bottom-space'])[" \
                            "13]/div/following-sibling::div/div/div/input[@class='oxd-input oxd-input--active']"
    # -------------------------------------------------------------
    Save_button1_locator = "(//button[@type='submit'])[1]"
    # ------------------------------------------------------
    Save_button2_locator = "(//button[@type='submit'])[2]"
    # ----------------------------------------------------
    Gender_locator = "(//span[@class='oxd-radio-input oxd-radio-input--active --label-right oxd-radio-input'])[1]"
    # ----------------------------------------------------
    Military_service_locator = "(//div[@class='oxd-input-group__label-wrapper'])[18]//following-sibling::div//input[" \
                               "@class='oxd-input oxd-input--active']"
    # ----------------------------------------------------
    Smoker_locator = "(//span[@class='oxd-checkbox-input oxd-checkbox-input--active --label-right " \
                     "oxd-checkbox-input'])[1]"
    # ----------------------------------------------------
    Blood_type_locator = "(//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow'])[3]"
    # ----------------------------------------------------
    Blood_select_locator = "//span[text() ='O+']"

    def other_id(self, other):
        self.personal_details.find_element(By.XPATH, self.Other_Id_locator).send_keys(other)

    def Driving_lic(self, number):
        self.personal_details.find_element(By.XPATH, self.Driving_lic_locator).send_keys(number)

    def Driving_lic_date(self, date):
        self.personal_details.find_element(By.XPATH, self.Driving_loc_Date_locator).send_keys(date)

    def SSIN_number(self, number):
        self.personal_details.find_element(By.XPATH, self.SSIN_number_locator).send_keys(number)

    def SIN_number(self, number):
        self.personal_details.find_element(By.XPATH,self.SIN_number_locator).send_keys(number)

    def Nationallity(self):
        self.personal_details.find_element(By.XPATH, self.Nationality_locator).click()
        time.sleep(10)
        self.personal_details.find_element(By.XPATH, self.Nationality_indian_locator).click()
        time.sleep(10)

    def Marital_Status(self):
        self.personal_details.find_element(By.XPATH, self.Martial_status_locator).click()
        time.sleep(5)
        self.personal_details.find_element(By.XPATH, self.Martial_status_single_locator).click()
        time.sleep(5)

    def Date_of_birth(self, date):
        self.personal_details.find_element(By.XPATH, self.Date_of_birth_locator).send_keys(date)

    def Gender(self):
        self.personal_details.find_element(By.XPATH, self.Gender_locator).click()

    def Military_service(self, years):
        self.personal_details.find_element(By.XPATH, self.Military_service_locator).send_keys(years)

    def Smoker(self):
        self.personal_details.find_element(By.XPATH, self.Smoker_locator).click()

    def Save_button1(self):
        self.personal_details.find_element(By.XPATH, self.Save_button1_locator).click()
        time.sleep(5)

    def Blood_type(self):
        scroll1 = self.personal_details.find_element(By.XPATH, self.Blood_type_locator)
        actions = ActionChains(self.personal_details)
        actions.scroll_to_element(scroll1).perform()
        time.sleep(5)
        self.personal_details.find_element(By.XPATH, self.Blood_type_locator).click()
        time.sleep(5)
        self.personal_details.find_element(By.XPATH, self.Blood_select_locator).click()
        time.sleep(5)

    def Save_button2(self):
        self.personal_details.find_element(By.XPATH, self.Save_button2_locator).click()
