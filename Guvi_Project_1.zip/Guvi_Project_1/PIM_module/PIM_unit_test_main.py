import time
import unittest

from selenium import webdriver
from PIM_module.pim_test import PIM_Module
from login_file.login_test import HrmLogin
from ulities_hrm.dashboard import wait_for_dashboard
from ulities_hrm.employee_list_button import emloyee_list_button


class PIMTestClass(unittest.TestCase):
    driver = None

    @classmethod
    def setUpClass(cls) -> None:
        print("i am before every test class")
        cls.driver = webdriver.Chrome()
        cls.driver.maximize_window()
        cls.driver.implicitly_wait(20)
        cls.driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
        Hrmobjct = HrmLogin(cls.driver)
        Hrmobjct.input_username('Admin')
        Hrmobjct.input_password('admin123')
        Hrmobjct.login_btn()
        assert wait_for_dashboard(cls.driver)

    def test_1add_Employee(self):
        HrmPim = PIM_Module(self.driver)
        HrmPim.Pim_Button()
        HrmPim.Add_button()
        HrmPim.Image()
        HrmPim.First_Name("Jimmy")
        HrmPim.Middle_Name("de")
        HrmPim.Last_Name("R")
        HrmPim.save_button()
        print("successfully added")
        time.sleep(5)
        assert HrmPim.Successful_added()
        time.sleep(5)
        HrmPim.Personal_detials()
        emloyee_list_button(self.driver)

    def test_2edit_employee(self):
        HrmPim = PIM_Module(self.driver)
        HrmPim.Pim_Button()
        HrmPim.employee_name("Jimmy")
        HrmPim.edit_emloyee()
        HrmPim.First_Name("Dude")
        HrmPim.Last_Name("123")
        time.sleep(2)
        HrmPim.Edit_save_button()
        emloyee_list_button(self.driver)

    def test_3delete_employee_details(self):
        HrmPim = PIM_Module(self.driver)
        HrmPim.Pim_Button()
        HrmPim.employee_name("Dude")
        HrmPim.delete_employee()
