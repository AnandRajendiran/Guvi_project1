import subprocess
import time

import keyboard as keyboard
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec

from PIM_module.personal_details import personal_details


class PIM_Module:

    def __init__(self, driver):
        self.Pim_test = driver

    PIM_locator = "//span[text()= 'PIM']"
    # ----------------------------------------------------
    add_button_Locator = "//button[text()=' Add ']"
    # ----------------------------------------------------
    First_name_locator = "firstName"
    # ----------------------------------------------------
    Middle_name_locator = "middleName"
    # ----------------------------------------------------
    Last_name_locator = "lastName"
    # ----------------------------------------------------
    Save_button_locator = "//button[text()=' Save ']"
    # ----------------------------------------------------
    Image_click_locator = "//div[@class='employee-image-wrapper']//following-sibling::button"
    # ----------------------------------------------------
    Successfully_added_locator = "//h6[@class='oxd-text oxd-text--h6 --strong']"
    # ----------------------------------------------------
    Employee_name_locator = "(//div[@class='oxd-autocomplete-text-input oxd-autocomplete-text-input--active'])[1]//input"
    # ----------------------------------------------------
    Search_employee_locator = "//button[text() =' Search ']"
    # ----------------------------------------------------
    Edit_employee_locator = "(//button[@class='oxd-icon-button oxd-table-cell-action-space'])[2]"
    # ----------------------------------------------------
    Edit_save_button_locator = "(//button[text() =' Save '])[1]"
    # ----------------------------------------------------
    delete_employee_locator = "(//div[@class='oxd-table-cell-actions'])[1]//following-sibling::button[1]"
    # ----------------------------------------------------
    confirm_delete = "//button[@class='oxd-button oxd-button--medium oxd-button--label-danger orangehrm-button-margin']"

    def Pim_Button(self):
        self.Pim_test.find_element(By.XPATH, self.PIM_locator).click()

    def Add_button(self):
        self.Pim_test.find_element(By.XPATH, self.add_button_Locator).click()

    def First_Name(self, firstname):
        self.Pim_test.find_element(By.NAME, self.First_name_locator).send_keys(firstname)
        time.sleep(2)

    def Middle_Name(self, middlename):
        self.Pim_test.find_element(By.NAME, self.Middle_name_locator).send_keys(middlename)
        time.sleep(2)

    def Last_Name(self, lastname):
        self.Pim_test.find_element(By.NAME, self.Last_name_locator).send_keys(lastname)
        time.sleep(2)

    def Image(self):
        self.Pim_test.find_element(By.XPATH, self.Image_click_locator).click()
        time.sleep(10)
        script_path = "C:\\Users\\Anand\\Desktop\\script.exe"
        subprocess.run(script_path, shell=True)
        time.sleep(3)

    def save_button(self):
        self.Pim_test.find_element(By.XPATH, self.Save_button_locator).click()

    def Successful_added(self):
        Profile_element = WebDriverWait(self.Pim_test, 20). \
            until(ec.presence_of_element_located((By.XPATH, self.Successfully_added_locator)))
        print("landed on profile")
        return Profile_element

    def Personal_detials(self):
        Pimpersonal = personal_details(self.Pim_test)
        Pimpersonal.other_id("12345")
        time.sleep(2)
        Pimpersonal.Driving_lic("97424782")
        time.sleep(2)
        Pimpersonal.Driving_lic_date("2033-11-12")
        time.sleep(2)
        Pimpersonal.SSIN_number("123456789")
        time.sleep(2)
        Pimpersonal.SIN_number("987654321")
        time.sleep(2)
        Pimpersonal.Date_of_birth("1988-11-17")
        time.sleep(2)
        Pimpersonal.Nationallity()
        Pimpersonal.Marital_Status()
        Pimpersonal.Gender()
        Pimpersonal.Military_service("20years")
        Pimpersonal.Smoker()
        Pimpersonal.Save_button1()
        Pimpersonal.Blood_type()
        Pimpersonal.Save_button2()
        time.sleep(3)

    def employee_name(self, name):
        self.Pim_test.find_element(By.XPATH, self.Employee_name_locator).send_keys(name)
        time.sleep(5)
        self.Pim_test.find_element(By.XPATH, self.Search_employee_locator).click()

    def edit_emloyee(self):
        self.Pim_test.find_element(By.XPATH, self.Edit_employee_locator).click()
        time.sleep(5)
        self.Pim_test.find_element(By.NAME, self.First_name_locator).click()
        keyboard.press_and_release('Ctrl + a')
        keyboard.press('Delete')
        time.sleep(5)
        self.Pim_test.find_element(By.NAME, self.Last_name_locator).click()
        keyboard.press_and_release('Ctrl + a')
        keyboard.press('Delete')

    def Edit_save_button(self):
        down_fall = self.Pim_test.find_element(By.XPATH, self.Edit_save_button_locator)
        action = ActionChains(self.Pim_test)
        action.scroll_to_element(down_fall).perform()
        time.sleep(3)
        self.Pim_test.find_element(By.XPATH, self.Edit_save_button_locator).click()

    def delete_employee(self):
        self.Pim_test.find_element(By.XPATH, self.delete_employee_locator).click()
        time.sleep(5)
        self.Pim_test.find_element(By.XPATH, self.confirm_delete).click()
        time.sleep(5)
