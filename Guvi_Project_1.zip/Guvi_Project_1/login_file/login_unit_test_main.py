import unittest
from selenium import webdriver
import time
from login_logout.logout_test import logout_webpage
from login_file.login_test import HrmLogin
from screenshot.screenshot_taken import take_screenshot
from ulities_hrm.dashboard import wait_for_dashboard


class LoginTestclass(unittest.TestCase):
    driver = None

    @classmethod
    def setUpClass(cls) -> None:
        print("i am before every test class")
        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(20)
        cls.driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")

    def test_successful(self):
        Hrmobjct = HrmLogin(self.driver)
        Hrmobjct.input_username('Admin')
        Hrmobjct.input_password('admin123')
        Hrmobjct.login_btn()
        assert wait_for_dashboard(self.driver)
        time.sleep(10)
        take_screenshot(self.driver)
        logout_webpage(self.driver)

    def test_unsuccessful(self):
        Hrmobjct = HrmLogin(self.driver)
        Hrmobjct.input_username('Admin')
        Hrmobjct.input_password('Invalid password')
        Hrmobjct.login_btn()
        assert Hrmobjct.invalid_password()
        time.sleep(10)
        take_screenshot(self.driver)
