from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec


class HrmLogin:

    def __init__(self, driver):
        self.Login_test = driver

    username_locator_string = "username"
    password_locator = "password"
    login_btn_locator = "//form/div[3]/button"
    invalid_credential = "//p[text()='Invalid credentials']"

    def input_username(self, username):
        self.Login_test.find_element(By.NAME, self.username_locator_string).send_keys(username)

    def input_password(self, password):
        self.Login_test.find_element(By.NAME, self.password_locator).send_keys(password)

    def login_btn(self):
        self.Login_test.find_element(By.XPATH, self.login_btn_locator).click()

    def invalid_password(self):
        invalid = WebDriverWait(self.Login_test, 20).until(ec.presence_of_element_located((By.XPATH,
                                                                                           self.invalid_credential)))
        return invalid
